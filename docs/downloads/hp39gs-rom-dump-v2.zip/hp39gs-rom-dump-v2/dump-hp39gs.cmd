@echo off
cd /d "%~dp0"
hp39-rom-receiver.exe -model hp39gs hp39gs-full.bin
pause
